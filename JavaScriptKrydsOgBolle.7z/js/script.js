
let playerXturn = true;
const gameboard = document.querySelector(".GameBoard");

const createEvt = (Fields) => {
    Fields.forEach((btn) => {
        btn.addEventListener("click", (e) =>{
        if (e.target.innerText == "") {
            e.target.innerText = playerXturn ? "X" : "O";
            playerXturn = !playerXturn;
            if (isWinnerFound()) alert("Vinder er fundet");
            }
        });
    });
};


const isWinnerFound = () => {
    for(let i = 0; i < 3; i++){
        if (
            document.querySelector("#r0c0").innerText === document.querySelector("#r0c1").innerText &&
            document.querySelector("#r0c0").innerText === document.querySelector("#r0c2").innerText &&
            document.querySelector("#r0c0").innerText !== ""
        ){
            return true;
    }  
        if (
            document.querySelector("#r0c0").innerText === document.querySelector("#r1c0").innerText &&
            document.querySelector("#r1c0").innerText === document.querySelector("#r2c0").innerText &&
            document.querySelector("#r0c0").innerText !== ""
        ){
            return true;
        }
        
    }
};

const init = () => {
    // for(let i = 0; i < 9; i++){
    // let btn = document.createElement("button")
    // btn.className ="Fields";
    // gameboard.appendChild(btn);
    // }

    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
            let btn = document.createElement("button")
            btn.className = "Fields";
            btn.id = `r${row}c${col}`;
            gameboard.appendChild(btn);
        }
    }

    
const Fields = document.querySelectorAll(".Fields");
createEvt(Fields);
}


init();